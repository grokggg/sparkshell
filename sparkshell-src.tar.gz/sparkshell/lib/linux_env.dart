import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:flutter/services.dart';

/// 把 APK 里自带的 proot + Debian rootfs 释放到私有目录，并拼出启动命令。
///
/// 目录布局（全部在 /data/data/com.grokggg.sparkshell/files 下）：
///   proot/proot            被 patch 过 loader 路径的 aarch64 静态入口
///   proot/loader            proot 的 ELF loader（路径必须与 patch 一致）
///   proot/libtalloc.so.2    依赖库
///   proot/libandroid-shmem.so
///   proot/libtermux-exec.so
///   rootfs/                 Debian bookworm arm64
///   tmp/                    proot 临时目录
class LinuxEnv {
  LinuxEnv._();

  static final LinuxEnv instance = LinuxEnv._();

  static const _prootFiles = [
    'proot/proot',
    'proot/loader',
    'proot/loader32',
    'proot/libtalloc.so.2',
    'proot/libandroid-shmem.so',
    'proot/libtermux-exec.so',
  ];

  bool _ready = false;

  Directory get _base => Directory('${Directory.systemTemp.parent.path}');

  Future<String> ensureReady(void Function(String) log) async {
    final files = await _appFilesDir();
    final prootDir = Directory('${files.path}/proot');
    final rootfs = Directory('${files.path}/rootfs');
    final tmp = Directory('${files.path}/tmp');
    await tmp.create(recursive: true);

    final prootBin = File('${prootDir.path}/proot');
    if (!await prootBin.exists()) {
      log('释放 proot 运行环境…');
      await prootDir.create(recursive: true);
      for (final name in _prootFiles) {
        final data = await rootBundle.load('assets/$name');
        final f = File('${files.path}/$name');
        await f.writeAsBytes(data.buffer.asUint8List(), flush: true);
      }
      await _chmod(prootBin.path);
      for (final n in ['loader', 'loader32']) {
        await _chmod('${prootDir.path}/$n');
      }
    }

    final marker = File('${rootfs.path}/.sparkshell_ready');
    if (!await marker.exists()) {
      log('解压 Debian rootfs（首次约需 1-3 分钟）…');
      await rootfs.create(recursive: true);
      final raw = await rootBundle.load('assets/rootfs.tar.gz');
      final tarBytes = const GZipDecoder().decodeBytes(raw.buffer.asUint8List());
      final archive = TarDecoder().decodeBytes(tarBytes);
      var n = 0;
      for (final e in archive) {
        final path = '${rootfs.path}/${e.name}';
        if (e.isFile) {
          final f = File(path);
          await f.parent.create(recursive: true);
          await f.writeAsBytes(e.content as List<int>, flush: false);
          n++;
        } else if (e.isSymbolicLink) {
          final l = Link(path);
          await l.parent.create(recursive: true);
          if (await l.exists()) await l.delete();
          await l.create(e.linkName, recursive: true);
        } else {
          await Directory(path).create(recursive: true);
        }
      }
      log('已解压 $n 个文件，执行 debootstrap 第二阶段…');
      await File('${rootfs.path}/etc/resolv.conf').writeAsString(
        'nameserver 223.5.5.5\nnameserver 119.29.29.29\n',
      );
      final r = await Process.run(
        prootBin.path,
        [
          '--link2symlink', '-0', '-r', rootfs.path,
          '-b', '/dev', '-b', '/proc', '-b', '/sys',
          '/debootstrap/debootstrap', '--second-stage',
        ],
        environment: _env(files.path, tmp.path),
      );
      log('第二阶段退出码 ${r.exitCode}');
      final tailText = '${r.stdout}\n${r.stderr}'.trim();
      if (tailText.isNotEmpty) log(tailText.split('\n').take(6).join('\n'));
      await marker.writeAsString(DateTime.now().toIso8601String());
    }

    _ready = true;
    return _launchScript(files.path, rootfs.path, tmp.path);
  }

  /// 写一个启动脚本，交给已有的 PTY 通道执行（execv 脚本即可）。
  Future<String> _launchScript(String base, String rootfs, String tmp) async {
    final sh = File('$base/proot/start.sh');
    final body = '''#!/system/bin/sh
export LD_LIBRARY_PATH=$base/proot
export PROOT_TMP_DIR=$tmp
export PROOT_L2S_DIR=$base/.l2s
exec $base/proot/proot --link2symlink -0 \\
  -r $rootfs \\
  -b /dev -b /proc -b /sys -b /storage -b /sdcard -b /data/data/com.grokggg.sparkshell/files \\
  -w /root \\
  /usr/bin/env -i HOME=/root TERM=xterm-256color LANG=C.UTF-8 \\
  PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \\
  /bin/bash -l
''';
    await sh.writeAsString(body, flush: true);
    await _chmod(sh.path);
    return sh.path;
  }

  Map<String, String> _env(String base, String tmp) => {
        'LD_LIBRARY_PATH': '$base/proot',
        'PROOT_TMP_DIR': tmp,
        'PROOT_L2S_DIR': '$base/.l2s',
        'HOME': '/root',
        'PATH': '/system/bin:/system/xbin',
      };

  Future<void> _chmod(String path) async {
    await Process.run('/system/bin/chmod', ['700', path]);
  }

  Future<Directory> _appFilesDir() async {
    // 走 Platform channel 拿 getFilesDir，避免依赖 path_provider。
    const ch = MethodChannel('com.xinghuo.sparkshell/pty');
    final dir = await ch.invokeMethod<String>('filesDir');
    return Directory(dir ?? _base.path);
  }

  bool get isReady => _ready;
}
