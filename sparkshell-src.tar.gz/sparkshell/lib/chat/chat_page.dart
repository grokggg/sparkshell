import 'dart:convert';
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../agent/agent_runner.dart';
import '../linux_env.dart';
import 'api_config.dart';
import 'llm_client.dart';

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _Msg {
  _Msg(this.role, this.text);
  final String role; // user | assistant
  String text;
}

class _ChatPageState extends State<ChatPage> {
  static const _ch = MethodChannel('com.xinghuo.sparkshell/pty');

  final _input = TextEditingController();
  final _scroll = ScrollController();
  final List<_Msg> _msgs = [];

  ApiConfig? _cfg;
  LlmClient? _client;
  StreamSubscription<String>? _sub;
  String? _filesDir;
  bool _busy = false;
  bool _agent = false;
  bool _autoApprove = false;
  String? _err;

  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    _filesDir = await _ch.invokeMethod<String>('filesDir');
    if (_filesDir == null) return;
    final cfg = await ApiConfig.load(_filesDir!);
    if (mounted) setState(() => _cfg = cfg);
  }

  @override
  void dispose() {
    _sub?.cancel();
    _client?.dispose();
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _toBottom() {
    if (!_scroll.hasClients) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.jumpTo(_scroll.position.maxScrollExtent);
      }
    });
  }

  Future<void> _send() async {
    final text = _input.text.trim();
    final cfg = _cfg;
    if (text.isEmpty || cfg == null || _busy) return;
    if (!cfg.ready) {
      setState(() => _err = '还没填 API Key，点右上角设置');
      return;
    }
    _input.clear();
    if (_agent) {
      await _sendAgent(text, cfg);
      return;
    }
    final reply = _Msg('assistant', '');
    setState(() {
      _msgs.add(_Msg('user', text));
      _msgs.add(reply);
      _busy = true;
      _err = null;
    });
    _toBottom();

    final history = _msgs
        .where((m) => m.text.isNotEmpty)
        .map((m) => {'role': m.role, 'content': m.text})
        .toList();

    final client = _client = LlmClient(cfg);
    final buf = StringBuffer();
    final done = Completer<void>();
    _sub = client.chat(history).listen(
      (delta) {
        buf.write(delta);
        setState(() => reply.text = buf.toString());
        _toBottom();
      },
      onError: (Object e) {
        setState(() => _err = '$e');
        if (!done.isCompleted) done.complete();
      },
      onDone: () {
        if (!done.isCompleted) done.complete();
      },
      cancelOnError: true,
    );
    await done.future;
    if (mounted) setState(() => _busy = false);
  }

  /// Agent 模式：模型要工具 → 弹窗审批 → 容器内执行 → 结果回灌。
  Future<void> _sendAgent(String text, ApiConfig cfg) async {
    setState(() {
      _msgs.add(_Msg('user', text));
      _busy = true;
      _err = null;
    });
    _toBottom();

    if (!LinuxEnv.instance.isReady) {
      setState(() => _msgs.add(_Msg('tool', '准备容器…')));
      final script = await LinuxEnv.instance.ensureReady((l) {
        if (mounted) setState(() => _msgs.add(_Msg('tool', l)));
      });
      if (script == null) {
        setState(() {
          _busy = false;
          _err = '容器没准备好，先去 Linux 页看一眼';
        });
        return;
      }
    }

    final history = _msgs
        .where((m) => m.role != 'tool' && m.text.trim().isNotEmpty)
        .map((m) => <String, dynamic>{'role': m.role, 'content': m.text})
        .toList();

    final runner = AgentRunner(
      cfg: cfg,
      onText: (t) {
        if (!mounted) return;
        setState(() => _msgs.add(_Msg('assistant', t)));
        _toBottom();
      },
      onToolResult: (t) {
        if (!mounted) return;
        setState(() => _msgs.add(_Msg('tool', t)));
        _toBottom();
      },
      approve: _approve,
    );

    try {
      await runner.run(history);
    } catch (e) {
      if (mounted) setState(() => _err = '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<bool> _approve(String name, Map<String, dynamic> args) async {
    if (_autoApprove) return true;
    final body = jsonEncode(args);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('允许执行 $name ？'),
        content: SingleChildScrollView(
          child: Text(
            body.length > 600 ? '${body.substring(0, 600)}…' : body,
            style: const TextStyle(fontSize: 12, fontFamily: 'monospace'),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('拒绝')),
          TextButton(
            onPressed: () {
              _autoApprove = true;
              Navigator.pop(ctx, true);
            },
            child: const Text('全部允许'),
          ),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('允许')),
        ],
      ),
    );
    return ok ?? false;
  }

  Future<void> _settings() async {
    final cfg = _cfg;
    if (cfg == null) return;
    final base = TextEditingController(text: cfg.baseUrl);
    final key = TextEditingController(text: cfg.apiKey);
    final model = TextEditingController(text: cfg.model);
    final sys = TextEditingController(text: cfg.systemPrompt);
    var temp = cfg.temperature;
    String? test;

    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('模型设置'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(
                controller: base,
                decoration: const InputDecoration(
                  labelText: 'Base URL',
                  hintText: 'https://api.deepseek.com/v1',
                ),
              ),
              TextField(
                controller: key,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'API Key'),
              ),
              TextField(
                controller: model,
                decoration: const InputDecoration(
                  labelText: '模型',
                  hintText: 'deepseek-chat / qwen-plus / gpt-4o-mini',
                ),
              ),
              TextField(
                controller: sys,
                maxLines: 3,
                decoration: const InputDecoration(labelText: '系统提示'),
              ),
              Row(children: [
                const Text('温度'),
                Expanded(
                  child: Slider(
                    value: temp,
                    min: 0,
                    max: 1,
                    divisions: 10,
                    label: temp.toStringAsFixed(1),
                    onChanged: (v) => setS(() => temp = v),
                  ),
                ),
              ]),
              if (test != null)
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(test!, style: const TextStyle(fontSize: 12)),
                ),
            ]),
          ),
          actions: [
            TextButton(
              onPressed: () async {
                final c = ApiConfig(
                  baseUrl: base.text,
                  apiKey: key.text,
                  model: model.text,
                  systemPrompt: sys.text,
                  temperature: temp,
                );
                setS(() => test = '测试中…');
                try {
                  final r = await LlmClient(c).ping();
                  setS(() => test = '✅ $r');
                } catch (e) {
                  setS(() => test = '❌ $e');
                }
              },
              child: const Text('测试连接'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('取消'),
            ),
            FilledButton(
              onPressed: () async {
                cfg
                  ..baseUrl = base.text.trim()
                  ..apiKey = key.text.trim()
                  ..model = model.text.trim()
                  ..systemPrompt = sys.text
                  ..temperature = temp;
                if (_filesDir != null) await cfg.save(_filesDir!);
                _client?.dispose();
                _client = null;
                if (ctx.mounted) Navigator.pop(ctx);
                if (mounted) setState(() {});
              },
              child: const Text('保存'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cfg = _cfg;
    return Scaffold(
      appBar: AppBar(
        title: Text(cfg == null ? 'Chat' : 'Chat · ${cfg.model}'),
        actions: [
          IconButton(
            tooltip: _agent ? 'Agent 模式：开' : 'Agent 模式：关',
            onPressed: () => setState(() => _agent = !_agent),
            icon: Icon(_agent ? Icons.smart_toy : Icons.smart_toy_outlined),
            color: _agent ? Theme.of(context).colorScheme.primary : null,
          ),
          IconButton(onPressed: _settings, icon: const Icon(Icons.settings)),
        ],
      ),
      body: Column(children: [
        if (_err != null)
          Container(
            width: double.infinity,
            color: Colors.red.withOpacity(0.15),
            padding: const EdgeInsets.all(8),
            child: Text(_err!, style: const TextStyle(fontSize: 12)),
          ),
        Expanded(
          child: _msgs.isEmpty
              ? Center(
                  child: Text(
                    cfg == null
                        ? '读取配置…'
                        : (cfg.ready
                            ? (_agent ? 'Agent 模式：让它改文件、跑命令' : '说点什么')
                            : '点右上角设置填 API Key'),
                    style: const TextStyle(color: Colors.grey),
                  ),
                )
              : ListView.builder(
                  controller: _scroll,
                  padding: const EdgeInsets.all(12),
                  itemCount: _msgs.length,
                  itemBuilder: (_, i) {
                    final m = _msgs[i];
                    final mine = m.role == 'user';
                    return Align(
                      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 4),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        constraints: const BoxConstraints(maxWidth: 320),
                        decoration: BoxDecoration(
                          color: m.role == 'tool'
                              ? Theme.of(context).colorScheme.surfaceContainerLow
                              : mine
                                  ? Theme.of(context).colorScheme.primaryContainer
                                  : Theme.of(context).colorScheme.surfaceContainerHighest,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: SelectableText(
                          m.text.isEmpty ? '…' : m.text,
                          style: TextStyle(
                            fontSize: m.role == 'tool' ? 11 : 13,
                            height: 1.4,
                            fontFamily: m.role == 'tool' ? 'monospace' : null,
                          ),
                        ),
                      ),
                    );
                  },
                ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: _input,
                  minLines: 1,
                  maxLines: 4,
                  textInputAction: TextInputAction.send,
                  onSubmitted: (_) => _send(),
                  decoration: const InputDecoration(
                    hintText: '输入消息…',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              _busy
                  ? IconButton.filled(
                      onPressed: () {
                        _sub?.cancel();
                        setState(() => _busy = false);
                      },
                      icon: const Icon(Icons.stop),
                    )
                  : IconButton.filled(
                      onPressed: _send,
                      icon: const Icon(Icons.send),
                    ),
            ]),
          ),
        ),
      ]),
    );
  }
}
