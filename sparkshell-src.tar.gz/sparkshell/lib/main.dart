import 'package:flutter/material.dart';
import 'chat/chat_page.dart';
import 'linux_page.dart';
import 'pty_terminal.dart';
import 'ssh_terminal.dart';
import 'webrtc_page.dart';

void main() => runApp(const SparkShellApp());

class SparkShellApp extends StatelessWidget {
  const SparkShellApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SparkShell',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: const Color(0xFF0B1020),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF7DE2D1),
          brightness: Brightness.dark,
        ),
      ),
      home: const Home(),
    );
  }
}

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int _idx = 0;

  static const _pages = [
    PtyTerminalPage(),
    LinuxPage(),
    ChatPage(),
    SshTerminalPage(),
    WebRtcPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SparkShell · linux/chat/ssh/webrtc'),
        centerTitle: false,
      ),
      body: IndexedStack(index: _idx, children: _pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _idx,
        onDestinationSelected: (i) => setState(() => _idx = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.terminal), label: 'PTY'),
          NavigationDestination(icon: Icon(Icons.computer), label: 'Linux'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'Chat'),
          NavigationDestination(icon: Icon(Icons.dns_outlined), label: 'SSH'),
          NavigationDestination(icon: Icon(Icons.wifi_tethering), label: 'WebRTC'),
        ],
      ),
    );
  }
}
