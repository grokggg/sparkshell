import 'dart:io';

import '../linux_env.dart';

/// Agent 可用的四个动作。全部作用在 proot 容器里，宿主目录不暴露。
///
/// 文件读写直接走宿主路径（rootfs 前缀），比再套一层 proot 快一个数量级；
/// 只有 bash 必须进容器，否则 glibc 动态链接器对不上。
class Tools {
  static const specs = <Map<String, dynamic>>[
    {
      'type': 'function',
      'function': {
        'name': 'bash',
        'description': '在 Debian/Alpine 容器内执行 shell 命令，返回 stdout+stderr。用于 ls、cat、apt、python3 等。',
        'parameters': {
          'type': 'object',
          'properties': {
            'command': {'type': 'string', 'description': '要执行的命令'},
            'timeout': {'type': 'integer', 'description': '秒，默认 60，最大 300'},
          },
          'required': ['command'],
        },
      },
    },
    {
      'type': 'function',
      'function': {
        'name': 'read_file',
        'description': '读取容器内文本文件，最多返回 8000 字符。',
        'parameters': {
          'type': 'object',
          'properties': {
            'path': {'type': 'string', 'description': '绝对路径，如 /root/a.py'},
            'offset': {'type': 'integer', 'description': '起始行，默认 1'},
          },
          'required': ['path'],
        },
      },
    },
    {
      'type': 'function',
      'function': {
        'name': 'write_file',
        'description': '写入（覆盖）容器内文本文件，自动建父目录。',
        'parameters': {
          'type': 'object',
          'properties': {
            'path': {'type': 'string'},
            'content': {'type': 'string'},
          },
          'required': ['path', 'content'],
        },
      },
    },
    {
      'type': 'function',
      'function': {
        'name': 'list_dir',
        'description': '列目录，返回名字/类型/大小。',
        'parameters': {
          'type': 'object',
          'properties': {
            'path': {'type': 'string', 'description': '绝对路径，默认 /root'},
          },
        },
      },
    },
  ];

  static Future<String> run(String name, Map<String, dynamic> args) async {
    try {
      switch (name) {
        case 'bash':
          return _bash(args);
        case 'read_file':
          return _read(args);
        case 'write_file':
          return _write(args);
        case 'list_dir':
          return _list(args);
        default:
          return '未知工具: $name';
      }
    } catch (e) {
      return '工具异常: $e';
    }
  }

  static Future<String> _bash(Map<String, dynamic> a) async {
    final cmd = (a['command'] as String? ?? '').trim();
    if (cmd.isEmpty) return '缺少 command';
    final secs = ((a['timeout'] as num?)?.toInt() ?? 60).clamp(5, 300);
    final r = await LinuxEnv.instance
        .execShell(cmd)
        .timeout(Duration(seconds: secs), onTimeout: () => ProcessResult(0, 124, '', '超时 ${secs}s'));
    final out = '${r.stdout}${r.stderr}'.trim();
    final body = out.length > 8000 ? '${out.substring(0, 8000)}\n…(截断)' : out;
    return '[exit ${r.exitCode}]\n${body.isEmpty ? '(无输出)' : body}';
  }

  static Future<String> _read(Map<String, dynamic> a) async {
    final f = _resolve(a['path'] as String?);
    if (f == null) return '路径非法';
    if (!await f.exists()) return '文件不存在: ${a['path']}';
    final lines = await f.readAsLines();
    final off = ((a['offset'] as num?)?.toInt() ?? 1).clamp(1, 1 << 30);
    final slice = lines.skip(off - 1).take(400).join('\n');
    return slice.length > 8000 ? '${slice.substring(0, 8000)}\n…(截断)' : slice;
  }

  static Future<String> _write(Map<String, dynamic> a) async {
    final f = _resolve(a['path'] as String?);
    if (f == null) return '路径非法';
    await f.parent.create(recursive: true);
    await f.writeAsString(a['content'] as String? ?? '', flush: true);
    final n = await f.length();
    return '已写入 ${f.path}，$n 字节';
  }

  static Future<String> _list(Map<String, dynamic> a) async {
    final f = _resolve(a['path'] as String? ?? '/root');
    if (f == null) return '路径非法';
    final dir = Directory(f.path);
    if (!await dir.exists()) return '目录不存在';
    final rows = <String>[];
    await for (final e in dir.list(followLinks: false)) {
      final name = e.path.split('/').last;
      if (e is Directory) {
        rows.add('d  $name/');
      } else if (e is Link) {
        rows.add('l  $name -> ${await e.target()}');
      } else {
        final len = await (e as File).length();
        rows.add('f  ${len.toString().padLeft(8)}  $name');
      }
    }
    rows.sort();
    return rows.isEmpty ? '(空目录)' : rows.take(200).join('\n');
  }

  /// 把容器内绝对路径映射到宿主 rootfs 下，拒绝 `..` 逃逸。
  static File? _resolve(String? path) {
    final root = LinuxEnv.instance.rootfsPath;
    if (root == null || path == null || path.isEmpty) return null;
    final parts = <String>[];
    for (final seg in path.split('/')) {
      if (seg.isEmpty || seg == '.') continue;
      if (seg == '..') {
        if (parts.isEmpty) return null;
        parts.removeLast();
      } else {
        parts.add(seg);
      }
    }
    return File('$root/${parts.join('/')}');
  }
}
