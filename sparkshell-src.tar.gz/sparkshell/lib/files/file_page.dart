import 'dart:async';

import 'package:flutter/services.dart';

import 'package:flutter/material.dart';

import 'fs_service.dart';

/// 容器文件浏览器：能看、能改、能把手机里的文件放进来。
///
/// rootPath 是宿主侧 rootfs 绝对路径（filesDir/rootfs），
/// 容器路径 /root/x 与宿主一一对应，所以这里不做 proot 转发。
class FilePage extends StatefulWidget {
  const FilePage({super.key, required this.rootPath, this.startPath = '/root'});

  final String rootPath;
  final String startPath;

  @override
  State<FilePage> createState() => _FilePageState();
}

class _FilePageState extends State<FilePage> {
  late final FsService _fs = FsService(widget.rootPath);
  late String _path = widget.startPath;
  List<FsEntry> _items = const [];
  bool _loading = true;
  String? _err;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _err = null;
    });
    try {
      final list = await _fs.list(_path);
      if (!mounted) return;
      setState(() {
        _items = list;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _err = '$e';
        _loading = false;
      });
    }
  }

  void _go(String path) {
    setState(() => _path = path.isEmpty ? '/' : path);
    _load();
  }

  void _up() {
    if (_path == '/' || _path.isEmpty) return;
    final idx = _path.lastIndexOf('/');
    _go(idx <= 0 ? '/' : _path.substring(0, idx));
  }

  /// 面包屑：/root/a/b → [('/', '/'), ('root', '/root'), ('a', '/root/a'), ('b', '/root/a/b')]
  List<(String, String)> get _crumbs {
    final out = <(String, String)>[('/', '/')];
    if (_path == '/' || _path.isEmpty) return out;
    final parts = _path.split('/').where((e) => e.isNotEmpty).toList();
    var acc = '';
    for (final p in parts) {
      acc = '$acc/$p';
      out.add((p, acc));
    }
    return out;
  }

  Future<void> _open(FsEntry e) async {
    if (e.isDir) {
      _go(e.path);
      return;
    }
    try {
      if (await _fs.isBinary(e.path)) {
        _toast('二进制文件，暂不支持预览（可长按复制路径）');
        return;
      }
      if (!mounted) return;
      await Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => EditorPage(fs: _fs, path: e.path),
      ));
      _load();
    } catch (err) {
      _toast('打不开：$err');
    }
  }

  Future<void> _import() async {
    try {
      final res = await const MethodChannel('sparkshell/io')
          .invokeMethod<List<dynamic>>('pickAndImportTo', {'destDir': _path});
      final n = res?.length ?? 0;
      _toast(n == 0 ? '没有选择文件' : '已导入 $n 个文件到 $_path');
      if (n > 0) _load();
    } on PlatformException catch (e) {
      _toast('导入失败：${e.message ?? e.code}');
    } catch (e) {
      _toast('导入失败：$e');
    }
  }

  Future<void> _newFolder() async {
    final name = await _ask('新建文件夹', '文件夹名');
    if (name == null || name.trim().isEmpty) return;
    try {
      await _fs.mkdir('$_path/$name'.replaceAll('//', '/'));
      _load();
    } catch (e) {
      _toast('创建失败：$e');
    }
  }

  Future<void> _sheet(FsEntry e) async {
    final action = await showModalBottomSheet<String>(
      context: context,
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.drive_file_rename_outline),
            title: const Text('重命名'),
            onTap: () => Navigator.pop(context, 'rename'),
          ),
          ListTile(
            leading: const Icon(Icons.delete_outline),
            title: const Text('删除'),
            onTap: () => Navigator.pop(context, 'delete'),
          ),
          ListTile(
            leading: const Icon(Icons.copy_all_outlined),
            title: const Text('复制路径'),
            onTap: () => Navigator.pop(context, 'copy'),
          ),
        ]),
      ),
    );
    if (!mounted || action == null) return;
    switch (action) {
      case 'rename':
        final name = await _ask('重命名', e.name);
        if (name == null || name.trim().isEmpty || name == e.name) return;
        try {
          await _fs.rename(e.path, '$_path/$name'.replaceAll('//', '/'));
          _load();
        } catch (err) {
          _toast('重命名失败：$err');
        }
        break;
      case 'delete':
        final ok = await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            title: Text('删除 ${e.name}？'),
            content: Text(e.isDir ? '目录及其中所有内容都会被删除，不可恢复。' : '文件将被删除，不可恢复。'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('取消')),
              FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('删除')),
            ],
          ),
        );
        if (ok != true) return;
        try {
          await _fs.delete(e.path);
          _load();
        } catch (err) {
          _toast('删除失败：$err');
        }
        break;
      case 'copy':
        await Clipboard.setData(ClipboardData(text: e.path));
        _toast('已复制 ${e.path}');
        break;
    }
  }

  Future<String?> _ask(String title, String initial) {
    final ctrl = TextEditingController(text: initial);
    return showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          decoration: const InputDecoration(hintText: '输入名称'),
          onSubmitted: (v) => Navigator.pop(context, v),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('取消')),
          FilledButton(onPressed: () => Navigator.pop(context, ctrl.text), child: const Text('确定')),
        ],
      ),
    );
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  static String _size(int b) {
    if (b < 1024) return '$b B';
    if (b < 1024 * 1024) return '${(b / 1024).toStringAsFixed(1)} KB';
    if (b < 1024 * 1024 * 1024) return '${(b / 1024 / 1024).toStringAsFixed(1)} MB';
    return '${(b / 1024 / 1024 / 1024).toStringAsFixed(2)} GB';
  }

  static String _time(DateTime? t) {
    if (t == null) return '';
    String two(int v) => v.toString().padLeft(2, '0');
    return '${two(t.month)}-${two(t.day)} ${two(t.hour)}:${two(t.minute)}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('文件'),
        actions: [
          IconButton(
            tooltip: '上一级',
            onPressed: _path == '/' ? null : _up,
            icon: const Icon(Icons.arrow_upward),
          ),
          IconButton(tooltip: '刷新', onPressed: _load, icon: const Icon(Icons.refresh)),
          IconButton(tooltip: '新建文件夹', onPressed: _newFolder, icon: const Icon(Icons.create_new_folder_outlined)),
          IconButton(tooltip: '导入手机文件', onPressed: _import, icon: const Icon(Icons.upload_file)),
        ],
      ),
      body: Column(children: [
        _breadcrumb(),
        const Divider(height: 1),
        Expanded(child: _body()),
      ]),
    );
  }

  Widget _breadcrumb() {
    final crumbs = _crumbs;
    return SizedBox(
      height: 36,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        itemCount: crumbs.length,
        separatorBuilder: (_, __) => const Icon(Icons.chevron_right, size: 14),
        itemBuilder: (_, i) {
          final (label, full) = crumbs[i];
          final last = i == crumbs.length - 1;
          return Center(
            child: InkWell(
              onTap: last ? null : () => _go(full),
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  color: last ? Theme.of(context).colorScheme.primary : null,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _body() {
    if (_loading) return const Center(child: CircularProgressIndicator(strokeWidth: 2));
    if (_err != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.error_outline, size: 40),
            const SizedBox(height: 12),
            Text(_err!, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton(onPressed: _load, child: const Text('重试')),
          ]),
        ),
      );
    }
    if (_items.isEmpty) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.folder_open, size: 40, color: Colors.white38),
          const SizedBox(height: 12),
          const Text('空目录'),
          const SizedBox(height: 4),
          Text('点右上角上传，把手机文件放进这里',
              style: Theme.of(context).textTheme.bodySmall),
        ]),
      );
    }
    return ListView.separated(
      itemCount: _items.length,
      separatorBuilder: (_, __) => const Divider(height: 1, indent: 56),
      itemBuilder: (_, i) {
        final e = _items[i];
        return ListTile(
          leading: Icon(
            e.isDir ? Icons.folder : Icons.description_outlined,
            color: e.isDir ? Colors.amber : null,
          ),
          title: Text(e.name, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: e.isDir ? null : Text('${_size(e.size)} · ${_time(e.modified)}'),
          trailing: e.isDir ? const Icon(Icons.chevron_right, size: 18) : null,
          onTap: () => _open(e),
          onLongPress: () => _sheet(e),
        );
      },
    );
  }
}

/// 文本编辑页。保存走 FsService.writeText，未保存返回会拦一下。
class EditorPage extends StatefulWidget {
  const EditorPage({super.key, required this.fs, required this.path});

  final FsService fs;
  final String path;

  @override
  State<EditorPage> createState() => _EditorPageState();
}

class _EditorPageState extends State<EditorPage> {
  final _ctrl = TextEditingController();
  bool _loading = true;
  bool _dirty = false;
  String? _err;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final text = await widget.fs.readText(widget.path);
      if (!mounted) return;
      _ctrl.text = text;
      setState(() => _loading = false);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _err = '$e';
        _loading = false;
      });
    }
  }

  Future<void> _save() async {
    try {
      await widget.fs.writeText(widget.path, _ctrl.text);
      if (!mounted) return;
      setState(() => _dirty = false);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('已保存 ${_ctrl.text.length} 字符')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('保存失败：$e')));
    }
  }

  Future<bool> _confirmDiscard() async {
    if (!_dirty) return true;
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('放弃修改？'),
        content: const Text('有未保存的改动，返回将丢失。'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('继续编辑')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('放弃')),
        ],
      ),
    );
    return ok ?? false;
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_dirty,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        if (await _confirmDiscard() && mounted) Navigator.pop(context);
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.path.split('/').last, overflow: TextOverflow.ellipsis),
          actions: [
            IconButton(tooltip: '保存', onPressed: _loading || _err != null ? null : _save, icon: const Icon(Icons.save_outlined)),
          ],
        ),
        body: _loading
            ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
            : _err != null
                ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_err!, textAlign: TextAlign.center)))
                : Padding(
                    padding: const EdgeInsets.all(12),
                    child: TextField(
                      controller: _ctrl,
                      maxLines: null,
                      expands: true,
                      textAlignVertical: TextAlignVertical.top,
                      style: const TextStyle(fontFamily: 'monospace', fontSize: 13, height: 1.35),
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        isDense: true,
                        hintText: '空文件，直接输入内容',
                      ),
                      onChanged: (_) {
                        if (!_dirty) setState(() => _dirty = true);
                      },
                    ),
                  ),
      ),
    );
  }
}
