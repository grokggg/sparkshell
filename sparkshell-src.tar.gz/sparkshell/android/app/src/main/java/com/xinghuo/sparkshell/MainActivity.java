package com.xinghuo.sparkshell;

import android.os.Bundle;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import androidx.annotation.NonNull;

import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;

/** 极简宿主：把 PTY 的 open/read/write/close 通过 MethodChannel 暴露给 Dart。 */
public class MainActivity extends FlutterActivity {

    private static final String CHANNEL = "com.xinghuo.sparkshell/pty";

    @Override
    public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);
        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), CHANNEL)
                .setMethodCallHandler(new MethodChannel.MethodCallHandler() {
                    @Override
                    public void onMethodCall(@NonNull MethodCall call, @NonNull MethodChannel.Result result) {
                        try {
                            switch (call.method) {
                                case "filesDir": {
                                    result.success(getApplicationContext().getFilesDir().getAbsolutePath());
                                    break;
                                }
                                case "prepareRootfs": {
                                    new Thread(new Runnable() {
                                        @Override
                                        public void run() {
                                            try {
                                                File files = getApplicationContext().getFilesDir();
                                                File marker = new File(files, "rootfs/.sparkshell_ready");
                                                File rootfs = new File(files, "rootfs");
                                                if (marker.exists()) {
                                                    result.success(true);
                                                    return;
                                                }
                                                File tar = new File(files, "rootfs.tar");
                                                InputStream in = getAssets().open("flutter_assets/assets/rootfs.tar");
                                                OutputStream out = new FileOutputStream(tar);
                                                byte[] buf = new byte[1 << 16];
                                                int n;
                                                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                                                out.close();
                                                in.close();
                                                rootfs.mkdirs();
                                                Process p = new ProcessBuilder(
                                                        "/system/bin/toybox", "tar", "-xf",
                                                        tar.getAbsolutePath(), "-C", rootfs.getAbsolutePath())
                                                        .redirectErrorStream(true).start();
                                                int code = p.waitFor();
                                                tar.delete();
                                                result.success(code == 0);
                                            } catch (Throwable t) {
                                                result.error("rootfs_error", String.valueOf(t.getMessage()), null);
                                            }
                                        }
                                    }).start();
                                    break;
                                }
                                case "open": {
                                    String shell = call.argument("shell");
                                    result.success(PtyBridge.open(shell == null ? "/system/bin/sh" : shell));
                                    break;
                                }
                                case "read": {
                                    Integer fd = call.argument("fd");
                                    Integer max = call.argument("max");
                                    if (fd == null || fd < 0) {
                                        result.success(null);
                                    } else {
                                        result.success(PtyBridge.read(fd, max == null ? 8192 : max));
                                    }
                                    break;
                                }
                                case "write": {
                                    Integer fd = call.argument("fd");
                                    byte[] data = call.argument("data");
                                    if (fd == null || fd < 0 || data == null) {
                                        result.success(-1);
                                    } else {
                                        result.success(PtyBridge.write(fd, data));
                                    }
                                    break;
                                }
                                case "close": {
                                    Integer fd = call.argument("fd");
                                    if (fd != null) PtyBridge.close(fd);
                                    result.success(true);
                                    break;
                                }
                                default:
                                    result.notImplemented();
                            }
                        } catch (Throwable t) {
                            result.error("pty_error", String.valueOf(t.getMessage()), null);
                        }
                    }
                });
    }
}
