package com.xinghuo.sparkshell;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;

/**
 * 极简宿主。
 *  - PTY 通道：open/read/write/close（native 实现在 pty_bridge.c）
 *  - 环境准备：prepareRootfs —— 把 APK 内的 rootfs.tar 流式落盘，再用 toybox tar 解包
 *
 * prepareRootfs 返回 String：成功为 "ok"，失败为可直接打印的诊断串（含 tar 退出码/输出/剩余空间）。
 * 之所以不再以 tar 退出码判定成败：解包 250 MB Debian rootfs 时 chown/mknod 类操作必然报错，
 * 退出码非 0 但文件是完整的；改为校验关键路径是否存在。
 */
public class MainActivity extends FlutterActivity {

    private static final String CHANNEL = "com.xinghuo.sparkshell/pty";
    private final Handler main = new Handler(Looper.getMainLooper());

    @Override
    public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);
        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), CHANNEL)
                .setMethodCallHandler(new MethodChannel.MethodCallHandler() {
                    @Override
                    public void onMethodCall(@NonNull MethodCall call, @NonNull MethodChannel.Result result) {
                        try {
                            switch (call.method) {
                                case "filesDir": {
                                    result.success(getApplicationContext().getFilesDir().getAbsolutePath());
                                    break;
                                }
                                case "prepareRootfs": {
                                    final MethodChannel.Result r = result;
                                    new Thread(() -> {
                                        String out;
                                        try {
                                            out = extractRootfs();
                                        } catch (Throwable t) {
                                            out = "异常: " + t;
                                        }
                                        final String msg = out;
                                        main.post(() -> r.success(msg));
                                    }).start();
                                    break;
                                }
                                case "open": {
                                    String shell = call.argument("shell");
                                    result.success(PtyBridge.open(shell == null ? "/system/bin/sh" : shell));
                                    break;
                                }
                                case "read": {
                                    Integer fd = call.argument("fd");
                                    Integer max = call.argument("max");
                                    if (fd == null || fd < 0) {
                                        result.success(null);
                                    } else {
                                        result.success(PtyBridge.read(fd, max == null ? 8192 : max));
                                    }
                                    break;
                                }
                                case "write": {
                                    Integer fd = call.argument("fd");
                                    byte[] data = call.argument("data");
                                    if (fd == null || fd < 0 || data == null) {
                                        result.success(-1);
                                    } else {
                                        result.success(PtyBridge.write(fd, data));
                                    }
                                    break;
                                }
                                case "close": {
                                    Integer fd = call.argument("fd");
                                    if (fd != null) PtyBridge.close(fd);
                                    result.success(true);
                                    break;
                                }
                                default:
                                    result.notImplemented();
                            }
                        } catch (Throwable t) {
                            result.error("pty_error", String.valueOf(t.getMessage()), null);
                        }
                    }
                });
    }

    /** @return "ok" 或诊断信息 */
    private String extractRootfs() throws Exception {
        File files = getApplicationContext().getFilesDir();
        File rootfs = new File(files, "rootfs");
        File marker = new File(rootfs, ".sparkshell_ready");
        if (marker.exists() && hasShell(rootfs)) return "ok";

        deleteTree(rootfs);
        if (!rootfs.mkdirs() && !rootfs.isDirectory()) return "无法创建 " + rootfs;

        File tar = new File(files, "rootfs.tar");
        long mb = 1024L * 1024L;
        try (InputStream in = getAssets().open("flutter_assets/assets/rootfs.tar");
             OutputStream out = new FileOutputStream(tar)) {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
        long freeBefore = files.getUsableSpace() / mb;
        if (freeBefore < tar.length() / mb + 100) {
            tar.delete();
            return "空间不足: 剩余 " + freeBefore + "MB，需要约 " + (tar.length() / mb + 120) + "MB";
        }

        Process p = new ProcessBuilder("/system/bin/toybox", "tar", "-xf",
                tar.getAbsolutePath(), "-C", rootfs.getAbsolutePath())
                .redirectErrorStream(true).start();
        StringBuilder log = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
            String line;
            int kept = 0;
            while ((line = br.readLine()) != null) {
                if (kept++ < 6) log.append(line).append(" / ");
            }
        }
        int code = p.waitFor();
        tar.delete();

        for (String d : new String[]{"dev", "proc", "sys", "tmp", "root", "home"}) {
            new File(rootfs, d).mkdirs();
        }

        if (!hasShell(rootfs)) {
            return "解包不完整: tar退出码=" + code + " 剩余=" + (files.getUsableSpace() / mb) + "MB tar输出=" + log;
        }
        marker.createNewFile();
        return "ok";
    }

    private static boolean hasShell(File rootfs) {
        return new File(rootfs, "bin/sh").exists()
                || new File(rootfs, "usr/bin/bash").exists()
                || new File(rootfs, "bin/bash").exists();
    }

    private static void deleteTree(File f) {
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteTree(k);
        f.delete();
    }
}
